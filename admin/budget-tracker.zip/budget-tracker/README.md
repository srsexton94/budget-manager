
# Budget Tracker
A chrome extension to accept users' spendings, display current total spending tally, set a spending limit, and notify the user if that limit is reached; as well as an options page to reset the total and limit.
* Built by expanding upon [Codevolution Chrome Extension Tutorial](https://www.youtube.com/watch?v=8q1_NkDbfzE&list=PLC3y8-rFHvwg2-q6Kvw3Tl_4xhxtIaNlY&index=1)

## Set Up & Installation
-   Create directory with manifest.json and popup.html

## Dependencies
-   [jQuery](https://api.jquery.com/)
-   [Bootstrap](https://getbootstrap.com/)
